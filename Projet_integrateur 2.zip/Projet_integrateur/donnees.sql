INSERT INTO users (username, password, email) VALUES 
('john_doe', 'password123', 'john.doe@example.com'),
('jane_smith', 'securepassword', 'jane.smith@example.com'),
('michael_brown', 'mypass2023', 'michael.brown@example.com'),
('alice_jones', 'alicepwd!', 'alice.jones@example.com'),
('chris_white', 'chris1234', 'chris.white@example.com');

INSERT INTO taches (idImportance, nomTache, descriptionTache) VALUES 
(1, 'Préparer la réunion', 'Organiser la réunion de projet pour la semaine prochaine'),
(2, 'Développer le module X', 'Implémenter les fonctionnalités du module X conformément aux spécifications'),
(3, 'Test de l\'application', 'Effectuer des tests de validation et de vérification sur la nouvelle version de l\'application'),
(1, 'Rédiger le rapport', 'Écrire le rapport hebdomadaire pour la direction'),
(2, 'Mise à jour du site web', 'Mettre à jour le contenu du site web de l\'entreprise avec les dernières nouvelles');
(3, 'Misessssss à jour du site web', 'Mettre à jour le contenu du site web de l\'entreprise avec les dernières nouvelles');


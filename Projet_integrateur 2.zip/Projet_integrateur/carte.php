<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="design.css">
    <title>Document</title>
</head>
<body>

<div class="card">
    <h2>Nom de la tache</h2>

    <h3>Description</h3>
    <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, dolor libero voluptatem 
        eveniet recusandae quo vel explicabo veritatis consequuntur aut 
        minus voluptatum error, qui labore sequi maiores quisquam hic. Omnis.
        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Officiis reprehenderit iure doloribus
        dicta hic eum, recusandae architecto
        deserunt facere culpa suscipit ipsam cupiditate enim modi! Optio quos ipsum neque et!
    </p>


    <h2>Importance</h2>

    

</div>
    
</body>
</html>